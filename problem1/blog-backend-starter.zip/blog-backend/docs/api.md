# 接口说明

所有响应都套一层信封：

```json
{ "code": 0, "msg": "ok", "data": null }
```

## 列表

`GET /todos`

`data` 是待办数组。

```json
{
  "code": 0,
  "msg": "ok",
  "data": [{ "id": 1, "title": "写题解", "finished": false }]
}
```
