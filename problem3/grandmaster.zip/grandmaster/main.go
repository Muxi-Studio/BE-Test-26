package main

import (
	"grandmaster/opponent"
)

func main() {
	/* A */

	for i := range 5 {
		go func( /* B */ ) {
			/* B */
		}( /* B */ )
	}

	go func() {
		/* C */
	}()

	for /* D */ {
		/* D */
	}
}
